/*1. create node project "npm init -y"
2. install mysql package "npm install mysql"
3. create a file like "database.js"
4. import mysql package "const { createPool } = require('mysql')"
5. create pool connection
-----------------------------------------*/
const { createPool } = require('mysql')

const pool = createPool({
    host: "localhost",
    user: "root",
    password: "root",
    database: "abhishek",
    connectionLimit: 10
})
/*6. execute query
---------------------------*/
pool.query(`select * from demo`, function(err, result, fields) {
    if (err) {
        return console.log(err);
    }
    return console.log(result);
})
