function add(a,b,c=0){
    //console.log(a+"+"+b+"+"+c);
    console.log(`${a}+${b}+${c} => ${a+b+c}`)
}

add(2,3)//5
add(2,3,4)//9
add(2,3,2,5)//7

add(2.5,5.2)
add(44,6.7,8.3)