let promise1=new Promise((resolve,reject)=>{ 
    setTimeout(()=>resolve("success"),3000)})

let promise2=Promise.resolve(11)

let promise3=55

Promise.all([promise1,promise2,promise3]).then(d=>console.log(d))
//promise1.then(msg=>console.log(msg))
//promise2.then(d=>console.log(d))
//promise3.then(d=>console.log(d))

/*
data
let a=data

Promise will provide data

let a=Promise -> data
*/