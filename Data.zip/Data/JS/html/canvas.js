let canvas=document.querySelector("canvas")
let c=canvas.getContext('2d');

c.fillRect(10,10,100,100)

c.fillStyle='red'
c.fillRect(100,100,200,200)

c.strokeStyle='blue'
c.moveTo(0,0)
c.lineTo(400,400)
c.lineTo(55,200)
c.stroke()