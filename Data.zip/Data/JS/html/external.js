 //alert("hello")
 console.log("Hello")

 function demo(){
     alert("Welcome")
 }

 function output(){
     //document.write("Hello")//not recommended
     document.querySelector("h1").innerHTML="Welcome"//recommended
     //document.querySelector("#id1").innerHTML="Good Morning"
     document.getElementById("id1").innerHTML="Good Morning"
     document.querySelector(".c1").innerHTML="Tea Break"
 }
 /*
 multiline
 comment
 */