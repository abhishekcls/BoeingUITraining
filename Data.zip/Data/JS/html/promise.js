function get(url) {
    return new Promise(function(resolve, reject) {
      let httpRequest = new XMLHttpRequest();
      httpRequest.open('GET', url);
      httpRequest.onload = function() {
        if (httpRequest.status === 200) {
          // Resolve the promise with the response text
          // success(httpRequest.responseText);
          resolve(httpRequest.response);
        } else {
          // Reject the promise with the status text
          // fail(httpRequest.status);
          reject(Error(httpRequest.statusText));
        }
      };
  
      // Handle network errors
      httpRequest.onerror = function() {
        reject(Error('Network Error'));
      };
  
      httpRequest.send();
    });
  }
 
  Promise.resolve(get('https://jsonplaceholder.typicode.com/posts')).then(data=>console.log(data))

  Promise.all([get('https://jsonplaceholder.typicode.com/posts/1'), get('https://jsonplaceholder.typicode.com/users/1')])
      .then(function(responses) {
       console.log(responses)
      })
      .catch(function(status) {
        console.log(status);
      })
      .finally(function() {
        console.log("finally")
      });