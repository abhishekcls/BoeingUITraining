var a=10//global
function outer(){
    var b=20//closure
    function inner(){
        var c=30//function
        console.log(a,b,c);
    }
    return inner
}

fx=outer()
fx()