var emp={
    "eid":101,
    "ename":"Deepak",
    "hobbies":["read","write","play"],
    "details":function(){
        //console.log("details of",this["ename"])
        /*for(hb in this.hobbies){
            console.log(this.ename,'likes to',this.hobbies[hb])
        }*/
        /*this.hobbies.forEach(function(v){
            console.log(this.ename,'likes to',v)
        },this)*/
        var that=this
        this.hobbies.forEach(function(v){
            console.log(that.ename,'likes to',v)
        })
    }
}

console.log(emp,typeof(emp))
emp.details()

/*function abc(v){
    console.log(this.ename,v)
}

var emp={
    "eid":101,
    "ename":"Deepak",
    "hobbies":["read","write","play"],
    "details":function(){
        //console.log("details of",this["ename"])
        //for(hb in this.hobbies){
        //    console.log(this.ename,'likes to',this.hobbies[hb])
        //}
        this.hobbies.forEach(abc,this)
    }
}

console.log(emp,typeof(emp))
emp.details()
*/
//task print hobbies using
//1 for..in
//2 forEach
/*
for(hb in emp.hobbies){
    console.log(emp.hobbies[hb])
}

function print(v){
    console.log(v)
}

emp.hobbies.forEach(print)

emp.hobbies.forEach(function(v,i){
    console.log(i,v)
})
*/