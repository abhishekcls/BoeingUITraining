//JSON -> Java Script Object Notation
//{propery:value}
//{property1:value1,property2:value2}

var emp={"eid":101,"ename":"Deepak"}
console.log(emp)
console.log(typeof(emp))

console.log(Array.isArray(emp))

console.log(emp.eid,emp.ename)
console.log(emp["eid"],emp["ename"])//recommended

for(e in emp){
    console.log(e,emp[e])
}

emp2=JSON.stringify(emp)//object to string
console.log(emp2)
console.log(typeof(emp2))

emp3=JSON.parse(emp2)//string to object
console.log(emp3)
console.log(typeof(emp3))

console.log(emp==emp3)//false
console.log(JSON.stringify(emp)==JSON.stringify(emp3))//true

var emp4=emp3
console.log(emp3==emp4)//true

emp3.ename="Abhishek"
console.log(emp3)
console.log(emp4)

emp=null