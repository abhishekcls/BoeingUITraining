var arr=[1,2,3,4,5]

var res=arr.map(function(v){
    return v+1
})
console.log(res);

//task
//even numbers
var res=arr.filter(function(v){
    return v%2==0
})
console.log(res);

var total=arr.reduce(function(p,c){
    console.log(p,c);
    return p+c
})

console.log(total)

console.log("*******************");
console.log("Arrow function");
let result=arr.map(v=>v+1)
console.log(result);
let evens=arr.filter(v=>v%2)
console.log(evens);
let sum=arr.reduce((p,c)=>p+c)
console.log(sum);