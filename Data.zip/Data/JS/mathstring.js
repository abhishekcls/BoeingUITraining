console.log(Math.PI)

console.log(Math.sqrt(4))

let text = "a,b,c,d,e,f";
const myArray = text.split(",");
console.log(myArray)

text="Abhishek"
console.log(text.split(""))

text=undefined