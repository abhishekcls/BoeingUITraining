let arr=[10,20,30,22,55]

/*
let a=arr[0]
let b=arr[1]
*/

let [a,b,...left]=arr//array destructuring

console.log(arr)

console.log(a,b,left)

let emp={"eid":101,"ename":"Deepak"}
emp["esal"]=75000

console.log(emp)
/*
let eid=emp.eid
let ename=emp.ename
*/

// let {eid,...extra}=emp//object destructuring
// console.log(eid,extra)

let {eid:id,ename:nm}=emp//object destructuring
console.log(id,nm)