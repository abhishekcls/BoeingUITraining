console.log("1")
/*
async function abc(){
    console.log("hello")
   // fetch('https://jsonplaceholder.typicode.com/users/1').
   // then(d=>console.log(d))
    return "abc"
}
*/
async function abc(){
    console.log("hello")
    response=await fetch('https://jsonplaceholder.typicode.com/users/1')
    data=await response.json()
    return data
}
async function xyz(){
    console.log("hi")
    return "xyz"
}


console.log("2")

async function demo(){
    try{
        res= await abc()
        res2=await xyz()
        console.log(res)
        console.log(res2)
    }
    catch(err){

    }
}

demo()

console.log("3")