/*function abc(){
    console.log("Hello");
}
abc=function(){
    console.log("Hello");
}
*/

abc=()=>{
    console.log("Hello");
}

abc()

add=(a,b)=>console.log(a+b);

add(2,3)

square=a=>a*a

console.log(square(4));

//syntactic sugar