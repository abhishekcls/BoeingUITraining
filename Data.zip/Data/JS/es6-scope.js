const a=10

console.log(a);

function abc(){
    //console.log(a) //hoisting not allowed //error
    const a=20
    if(true){
        const a=30//block scope
        //a=40//error
        console.log(a)
    }
    console.log(a)
}

abc()