var a=10;//global

console.log(a);

function abc(){
    //var a=20;
    console.log(a);//hoisting
    if(false){
        var a=30;
        console.log(a);
    }
    console.log(a);
}

abc()
console.log(a)

