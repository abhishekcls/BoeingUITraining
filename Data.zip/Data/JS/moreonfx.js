function add(a,b){
    //console.log(a+b)
    return a+b
}

console.log(add(1,4))