//var emp={"eid":101,"ename":"Deepak"}
//var emp2={"eid":102,"ename":"Prateek"}

//1. Factory
/*function EmployeeFactory(eid,ename){
    return{
        eid,
        ename
    }
}
var emp1=EmployeeFactory(101,"Tarun")
console.log(emp1);
console.log(typeof(emp1));
var emp2=EmployeeFactory(102,"Varun")
console.log(emp2);
console.log(typeof(emp2));
*/
//2. Constructor
function Employee(eid,ename){
    this.eid=eid
    this.ename=ename
}

var emp3=new Employee(103,"Priya")
console.log(emp3);
console.log(typeof(emp3));
var emp4=new Employee(104,"Punit")
console.log(emp4);
console.log(typeof(emp4));