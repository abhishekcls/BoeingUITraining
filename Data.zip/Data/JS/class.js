class Demo{
    //name="Abhishek"//error in older ver of nodejs
    constructor(n){
        this.name=n
        console.log("cons")
    }
    disp(){
        console.log("Hello",this.name)
    }
}

let obj=new Demo("Abhishek Samanta")//object
obj.disp()

console.log(obj,typeof(obj))

let obj2=new Demo("Tarun")//object
obj2.disp()

console.log(obj2,typeof(obj2))