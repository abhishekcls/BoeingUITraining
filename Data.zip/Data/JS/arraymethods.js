var fruits=['apple','banana','kiwi']
console.log(fruits)
console.log(fruits.join(", "))
console.log(fruits.join(" * "))

//console.log(fruits.pop());
//console.log(fruits.shift());

fruits.unshift("grapes")
console.log(fruits)

const myGirls = ["Cecilie", "Lone"];
const myBoys = ["Emil", "Tobias", "Linus"];
const myChildren = myGirls.concat(myBoys);

console.log(myChildren);

const arr1 = ["Cecilie", "Lone"];
const arr2 = ["Emil", "Tobias", "Linus"];
const arr3 = ["Robin", "Morgan"];
const merged = arr1.concat(arr2, arr3);

console.log(merged)

const arr11 = ["Emil", "Tobias", "Linus"];
const res = arr11.concat("Peter"); 

console.log(res)
fruits.splice(2, 0, "Lemon", "Mango");
console.log(fruits)
const citrus = fruits.slice(1);
console.log(citrus)


