var n=null
console.log(n,typeof(n))

var i=10
var j=10

console.log(i==j)
console.log(typeof(i),typeof(j))

var a=new Number(10)
var b=new Number(10)

console.log(typeof(a),typeof(b))
console.log(a==b)

var s1="abc"
var s2="abc"

console.log(s1==s2)

var str1=new String("abc")
var str2=new String("abc")

console.log(str1==str2)

var b1=true
var b2=true

console.log(b1==b2)

var bool1=new Boolean(true)
var bool2=new Boolean(true)

console.log(bool1==bool2)

var arr=new Array(10)
console.log(arr,typeof(arr))

var d=new Date()
console.log(d,typeof(d))