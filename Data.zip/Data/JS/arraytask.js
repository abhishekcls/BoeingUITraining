scores=[5,1,2,100,11]
console.log(scores)
console.log(typeof(scores))
console.log(Array.isArray(scores))
var emp={"eid":101,"ename":"Deepak"}

['abc',12,true,emp,scores]

abc=[[1,2],[3,4]]

abc.push([2,3,4])

scores.sort(function (a,b){
    return a-b
})

console.log(scores)
//task to sort scores array
/*
var fruits=['apple','banana','kiwi']

console.log(fruits)
fruits[3]="grapes"
console.log(fruits)
fruits[fruits.length]="orange"
console.log(fruits)
fruits.push("guava")
console.log(fruits)

fruits.sort()
console.log(fruits)
fruits.reverse()
console.log(fruits)
*/