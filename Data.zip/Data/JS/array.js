var fruits=['apple','banana','kiwi']

console.log(fruits)
console.log(typeof(fruits))

console.log(fruits[0],typeof(fruits[0]))

console.log("==========for============")
for(var i=0;i<fruits.length;i++){
    console.log(fruits[i])
}
console.log("==========while============")
i=0;
while(i<fruits.length){
    console.log(fruits[i++])
}
console.log("==========do..while============")
i=0;
do{
    console.log(fruits[i])
    i++
}while(i<fruits.length);

console.log("==========for..in============")
for(i in fruits){
    console.log(i,fruits[i])
}

console.log("==========for..of============")
for(let f of fruits){
    console.log(f)
}

console.log("==========foreach============")
function show(v,i,arr){
    console.log(i,v,arr)
}

fruits.forEach(show)
console.log("==========foreach2============")

fruits.forEach(function(v){
    console.log(v)
})

console.log("==========foreach arrow============")

fruits.forEach(v=>console.log(v))