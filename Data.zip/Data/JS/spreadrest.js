function add(...args){//rest
    //console.log(args)
    let sum=0
    for(let a of args){
        sum+=a
    }
    console.log(sum)
}

add(2,3)
add(2,3,7)
add(2,3,7,6)
add(2,3,7,2,5)
add(4,5,1,1,1,2,2,3,4,6,7,8)

arr=[1,2,3,7]

add(...arr)//spread
add(1,...arr)//spread
console.log(...arr)

arr2=[...arr]//array copy
console.log(arr)
console.log(arr2)
arr2[2]=11
console.log(arr)
console.log(arr2)

let emp={"eid":101,"ename":"Deepak"}
let empcopy={...emp}//spread for copying object
emp.ename='Abhishek'
console.log(emp)
console.log(empcopy)