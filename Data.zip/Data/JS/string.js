let s1='Abhishek'
let s2="Abhishek"
let s3=`Abhishek`//recommend

console.log(s1,typeof(s1))
console.log(s2,typeof(s2))
console.log(s3,typeof(s3))

console.log('Fathers\' Day');
console.log("Fathers' Day");

console.log('5"');
console.log("5\"");

console.log('5\'9"');
console.log("5'9\"");
console.log(`5'9"`);

console.log('Hello '+ s1);//es5
console.log(`Hello ${s1}`);//es6