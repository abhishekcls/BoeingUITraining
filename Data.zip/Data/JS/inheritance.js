class Parent{
    a=0
    constructor(a){
        this.a=a
        console.log("P cons",a);
    }
    disp(){
        console.log("Parent");
    }
}

class Child extends Parent//inheritance
{
    b=0
    constructor(a,b){
        super(a)
        this.b=b
        console.log("C cons",b);
    }
    disp(){
        console.log("Child");
    }
}

let c=new Child(10,20);
c.disp()