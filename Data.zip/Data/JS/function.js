//1 standard
// function abc(){
//     console.log("Hello")
// }

// abc()

//2 anonymous
// abc=function(){
//     console.log("Hello")
// }

// abc()

//3 IIFE -> Immediately Invoked Function Expressions
// (function(){
//     console.log("Hello")
// })()

/*
abc=function(){
    console.log("Hello")
}

abc()

abc=function(){
    console.log("Hi")
}

abc()
//output Hello Hi
*/
function abc(){
    console.log("Hello")
}

abc()

function abc(){
    console.log("Hi")
}

abc()
//output Hi Hi

console.log(typeof(abc))