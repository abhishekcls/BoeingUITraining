//https://www.sqlitetutorial.net/sqlite-nodejs/connect/
const sqlite3 = require('sqlite3').verbose();

// open database in memory
//let db = new sqlite3.Database(':memory:');

let db = new sqlite3.Database('abhishek.db', (err) => {
    if (err) {
      return console.error(err.message);
    }
    console.log('Connected to SQlite database.');
    //db.exec("create table demo(id integer,name text)")

    db.exec("insert into demo values(2,'bbb')")
  });

//db.close()
db.close((err) => {
    if (err) {
      return console.error(err.message);
    }
    console.log('Closed the database connection.');
  });

